for freelance work? do reach, [email](mailto:abhishknads.work@gmail.com) :)

📊 **this week i spent my time on:**
<!--START_SECTION:waka-->

```txt
TypeScript   14 hrs 58 mins  █████████████████████████   99.69 %
JSON         2 mins          ░░░░░░░░░░░░░░░░░░░░░░░░░   00.31 %
```

<!--END_SECTION:waka-->

if you like what i do, maybe consider buying me a coffee/tea 🥺👉👈

<a href="https://www.buymeacoffee.com/abhisheknaiidu" target="_blank"><img src="https://cdn.buymeacoffee.com/buttons/v2/default-red.png" alt="Buy Me A Coffee" width="150" ></a>

🚧 **my todoist stats:**
<!-- TODO-IST:START -->
🏆  8,004 Karma Points           
🌸  Completed 0 tasks today           
✅  Completed 673 tasks so far           
⏳  Longest streak is 10 days
<!-- TODO-IST:END -->


📈 my github stats

<p align="center"> <img src="https://github-readme-stats.vercel.app/api?username=abhisheknaiidu&show_icons=true&theme=gotham" alt="abhisheknaiidu" />




